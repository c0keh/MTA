/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package l3_da;

import java.util.List;
import javax.persistence.EntityManager;
import l4_dm.DmAufgabe;

/**
 *
 * @author s844559
 */
public class DaGenericImpl<E extends DmAufgabe> implements DaGeneric<E> {
    
    private final Class<E> managedClass;
    private final EntityManager em;
      
    public DaGenericImpl (Class<E> managedClass, EntityManager em) { 
        this.managedClass = managedClass;
        this.em = em; 
    }
    
    @Override
    public boolean save(DmAufgabe entity) {
        if(entity.getId() == null) {
            em.merge(entity);
            return false;
        }
        else {
            em.persist(entity);
            return true;
        }
    }

    @Override
    public void delete(DmAufgabe entity) {
        em.remove(entity);

    }

    @Override
    public E find(Long id) throws IdNotFoundExc {
        E entity = em.find(managedClass, id);
        if (entity == null) throw multex.MultexUtil.create(IdNotFoundExc.class, managedClass.getName(), id);
        return entity;
    }

    @Override
    public List findAll() {
       return em.createQuery("Select a from " + managedClass.getName() + " a").getResultList();
    }

    @Override
    public List findByField(String fieldName, Object fieldValue) {
      return em.createQuery("Select a from " + managedClass.getName() + " a where a." + fieldName + " = " + fieldValue).getResultList();  
    }

    @Override
    public List findByWhere(String whereClause, Object... args) {
        // return em.createQuery("Select * from " + managedClass.getName() + whereClause + args).getResultList();
        return null;
    }

    @Override
    public List findByExample(DmAufgabe example) {
        // return em.createQuery("Select a from " + managedClass.getName() + " where a is like a." + example).getResultList();
        return null;
    }
}