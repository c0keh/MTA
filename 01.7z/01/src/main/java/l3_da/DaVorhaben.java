package l3_da;

import l4_dm.DmVorhaben;

public interface DaVorhaben extends DaGeneric<DmVorhaben> {

}
