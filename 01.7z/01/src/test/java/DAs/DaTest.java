/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package DAs;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;
import l3_da.DaAufgabe;
import l3_da.DaFactoryForJPA;
import l4_dm.DmSchritt;
import org.junit.Assert;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

/**
 *
 * @author s844559
 */

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class DaTest {
    
    private static final String persistenceUnitName = "aufgabenplaner";
    private static final EntityManagerFactory entityManagerFactory = Persistence.createEntityManagerFactory(persistenceUnitName);
    DaFactoryForJPA daFac;
    
    
    public DaTest() {}
    
    @Test
    public void t01_() {
    final DaFactoryForJPA daFac = new DaFactoryForJPA();
    daFac.beginTransaction();
    DaAufgabe daAufg = daFac.getAufgabeDA(); 
    DmSchritt schritt = new DmSchritt();
    daAufg.save(schritt);
    daFac.endTransaction(true);
    }
    
    @Test
    public void t02_() {
        
    }
    
    @Test
    public void t03_() {
        
    }
    
    @Test
    public void t04_() {
        
    }
}
