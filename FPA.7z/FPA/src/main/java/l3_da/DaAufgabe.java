package l3_da;

import l4_dm.DmAufgabe;

/**Polymorphic Data Access Service for subclasses of DmAufgabe.*/
public interface DaAufgabe extends DaGeneric<DmAufgabe> {

}
