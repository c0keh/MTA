/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package l3_da;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

/**
 *
 * @author s844559
 */
public class DaFactoryForJPA implements DaFactory {

    private static final String persistenceUnitName = "aufgabenplaner";
    private final EntityManagerFactory emf;
    private final EntityManager em;
    private EntityTransaction ta = null;

    public DaFactoryForJPA() {
        emf = Persistence.createEntityManagerFactory(persistenceUnitName);
        em = emf.createEntityManager();
    }

    public void beginTransaction() {
        ta = em.getTransaction();
        ta.begin();
    }

    public void endTransaction(boolean ok) {
        if (ok == true) {
            ta.commit();
        }
        if (ok == false) {
            ta.rollback();
        }
        em.clear();
    }

    @Override
    public DaAufgabe getAufgabeDA() {
        return new DaAufgabeImpl(em);
    }

    @Override
    public DaSchritt getSchrittDA() {
        return new DaSchrittImpl(em);

    }

    @Override
    public DaVorhaben getVorhabenDA() {
        return new DaVorhabenImpl(em);
    }
}
