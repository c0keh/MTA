package l3_da;

import l4_dm.DmSchritt;

public interface DaSchritt extends DaGeneric<DmSchritt> {

}
