/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package l3_da;

import javax.persistence.EntityManager;
import l4_dm.DmSchritt;

/**
 *
 * @author s844559
 */
class DaSchrittImpl extends DaGenericImpl<DmSchritt> implements DaSchritt {
    
    public DaSchrittImpl(final EntityManager entityManager){
        super(DmSchritt.class, entityManager);
    }
}
