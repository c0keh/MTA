/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package DAs;

import l3_da.DaFactoryForJPA;
import l3_da.DaGeneric;
import l3_da.DaSchritt;
import l4_dm.DmSchritt;
import org.junit.Assert;
import static org.junit.Assert.fail;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

/**
 *
 * @author Rene
 */
@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class DaSchrittImplTest {

   private static final DaFactoryForJPA DA_FAC = new DaFactoryForJPA();

    public DaSchrittImplTest() {
    }

    /**
     * *
     */
    @Test
    public void t01_persistierenOhneRollback() {
        //speichern
        DA_FAC.beginTransaction();
        DaSchritt daSchritt1 = DA_FAC.getSchrittDA();
        DmSchritt dmSchritt = new DmSchritt();
        daSchritt1.save(dmSchritt);         //speichern
        DA_FAC.endTransaction(true);        // commit

        //laden und prüfen
        DA_FAC.beginTransaction();
        DaSchritt daSchritt2 = DA_FAC.getSchrittDA();
        Assert.assertEquals(1, daSchritt2.findAll().size());
        DA_FAC.endTransaction(true);
    }

    @Test
    public void t02_rollbackAusprobieren() {
        //speichern
        DA_FAC.beginTransaction();
        DaSchritt daSchritt1 = DA_FAC.getSchrittDA();
        DmSchritt dmSchritt = new DmSchritt();
        daSchritt1.save(dmSchritt);         // speichern
        DA_FAC.endTransaction(false);       // rollback

        //laden und prüfen
        DA_FAC.beginTransaction();
        DaSchritt daSchritt2 = DA_FAC.getSchrittDA();
        Assert.assertEquals(1, daSchritt2.findAll().size()); // weiterhin Größe 1?
        DA_FAC.endTransaction(true);
    }

    @Test
    public void t03_IdNotFoundExcAusprobieren() throws Exception {
        DA_FAC.beginTransaction();
        final DaSchritt daSchritt1 = DA_FAC.getSchrittDA();
        try {
            daSchritt1.find(99L);
            fail("DaGeneric.IdNotFoundExc expected");
        } catch (DaGeneric.IdNotFoundExc expected) {
        }
        finally {
        DA_FAC.endTransaction(true);
    }
    }

    @Test
    public void t04_deleteAusprobieren() {

        //löschen
        DA_FAC.beginTransaction();
        DaSchritt daSchritt1 = DA_FAC.getSchrittDA();
        daSchritt1.delete(daSchritt1.find(1L));     // erster (und einziger) Eintrag wird gelöscht
        DA_FAC.endTransaction(true);                // commit

        //laden und prüfen
        DA_FAC.beginTransaction();
        DaSchritt daSchritt2 = DA_FAC.getSchrittDA();
        Assert.assertEquals(0, daSchritt2.findAll().size());    // leer?
        DA_FAC.endTransaction(true);
    }
}
