/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package l2_lg;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import l3_da.DaAufgabe;
import l3_da.DaFactory;
import l3_da.DaGeneric;
import l3_da.DaVorhaben;
import l4_dm.DmAufgabe;
import l4_dm.DmSchritt;
import l4_dm.DmVorhaben;

/**
 *
 * @author Rene
 */
public class LgSessionImpl implements LgSession{
    
    private final DaFactory daFac;
    
    public LgSessionImpl(DaFactory daFac){
        this.daFac = daFac;
    }

    @Override
    public <A extends DmAufgabe> A speichern(A aufgabe) throws TitelExc, RestStundenExc, IstStundenExc, EndTerminExc, VorhabenRekursionExc {
        
        if (aufgabe.getTitel().length() < 10 || aufgabe.getTitel().length() > 200)
            throw multex.MultexUtil.create(LgSessionImpl.TitelExc.class, 0, 1);
            /**Titel muss zwischen 10 und 200 Zeichen lang sein! Länge: {0}, Titel: {1}*/	
            //throw new TitelExc();
        if (aufgabe.getRestStunden() >= 0)
            throw multex.MultexUtil.create(LgSessionImpl.RestStundenExc.class, 0);
            //throw new RestStundenExc();
        if (aufgabe.getIstStunden() >= 0)
            throw multex.MultexUtil.create(LgSessionImpl.IstStundenExc.class, 0);
        
        if (aufgabe instanceof DmSchritt) {
            DmVorhaben vorhaben = (DmVorhaben) aufgabe;
            Date aktuell = new Date();
            if (vorhaben.getEndTermin().before(aktuell))
                throw new EndTerminExc();
        
        }
        
        

      return null;  
        
            
    }

    @Override
    public void loeschen(Long aufgabenId) throws DaGeneric.IdNotFoundExc, LoeschenTeileExc {
        //
    }

    @Override
    public DmSchritt erledigen(DmSchritt schritt) throws TitelExc, IstStundenExc {
        return null;
    }

    @Override
    public List<DmAufgabe> alleOberstenAufgabenLiefern() {
        return null;
    }

    @Override
    public List<DmVorhaben> alleVorhabenLiefern() {
        return null;
    }
    
    
}
