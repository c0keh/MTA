/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package l2_lg;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import l3_da.DaAufgabe;
import l3_da.DaFactory;
import l3_da.DaGeneric;
import l3_da.DaSchritt;
import l4_dm.DmAufgabe;
import l4_dm.DmAufgabeStatus;
import l4_dm.DmSchritt;
import l4_dm.DmVorhaben;
import static multex.MultexUtil.create;

/**
 *
 * @author Rene
 */
class LgSessionImpl implements LgSession {

    DaFactory daFac;
    DaAufgabe aufgabe = daFac.getAufgabeDA();
    List<DmAufgabe> ganzeListe = aufgabe.findAll();  // alle Objekte der Liste laden
    ArrayList<DmAufgabe> rekursiveListe = new ArrayList<>();

    public LgSessionImpl(DaFactory daFac) {
        this.daFac = daFac;
    }

    @Override
    public <A extends DmAufgabe> A speichern(A aufgabe) throws TitelExc, RestStundenExc, IstStundenExc, EndTerminExc, VorhabenRekursionExc {

        if (aufgabe.getTitel().length() < 10 || aufgabe.getTitel().length() > 200) {
            throw create(
                    TitelExc.class,
                    aufgabe.getTitel().length(), aufgabe.getTitel()
            );
        }
        if (aufgabe.getRestStunden() < 0) {
            throw create(
                    RestStundenExc.class,
                    aufgabe.getRestStunden()
            );
        }
        if (aufgabe.getIstStunden() < 0) {
            throw create(
                    IstStundenExc.class,
                    aufgabe.getIstStunden()
            );
        }
        if (aufgabe instanceof DmVorhaben) {
            DmVorhaben vorhAktuellaben = (DmVorhaben) aufgabe;
            Date aktuell = new Date();
            if (vorhAktuellaben.getEndTermin().before(aktuell)) {
                throw create(
                        EndTerminExc.class,
                        ((DmVorhaben) aufgabe).getEndTermin()
                );
            }
        }
        //+++++++++ VorhabenRekursionExc, LoeschenTeileExc fehlt

        DaAufgabe speichern = daFac.getAufgabeDA();
        daFac.beginTransaction();
        speichern.save(aufgabe);
        daFac.endTransaction(true);
        return aufgabe;
    }

    @Override
    public void loeschen(Long aufgabenId) throws DaGeneric.IdNotFoundExc, LoeschenTeileExc {

        if (aufgabe.find(aufgabenId) == null) {
            throw create(
                    DaGeneric.IdNotFoundExc.class,
                    null
            );
        }
        if (aufgabe.findAll() != null) {
            throw create(
                    LoeschenTeileExc.class,
                    aufgabe.find(aufgabenId).getAnzahlTeile()
            );
        }

        daFac.beginTransaction();
        aufgabe.delete(aufgabe.find(aufgabenId));
        daFac.endTransaction(true);
    }

    //---------- Date-Package in DmSchritt auf .util geändert
    @Override
    public DmSchritt erledigen(DmSchritt schritt) throws TitelExc, IstStundenExc {

        if (schritt.getTitel().length() < 10 || schritt.getTitel().length() > 200) {
            throw create(
                    TitelExc.class,
                    schritt.getTitel().length(), schritt.getTitel()
            );
        }
        if (schritt.getIstStunden() < 0) {
            throw create(
                    IstStundenExc.class,
                    schritt.getIstStunden()
            );
        }

        daFac.beginTransaction();
        DaSchritt daSchritt = daFac.getSchrittDA();
        schritt.setRestStunden(0);
        schritt.setErledigtZeitpunkt(new Date());
        daSchritt.save(schritt);
        daFac.endTransaction(true);
        return schritt;
    }

    @Override
    public List<DmAufgabe> alleOberstenAufgabenLiefern() {

        ArrayList<DmAufgabe> neueListe = new ArrayList<>();
        daFac.beginTransaction();
        // durchlaeuft alle Aufgaben und sucht nach den Elementen, die keine ganzes-Referenz haben
        for (DmAufgabe aufgAktuell : ganzeListe) {

            if (aufgAktuell.getGanzes() == null) {
                if (aufgAktuell instanceof DmVorhaben) {
                    DmVorhaben vorhAktuell = (DmVorhaben) aufgAktuell;

                    // erstellt Liste aller Teile des Elements
                    for (DmAufgabe aufg2 : ganzeListe) {
                        if (aufg2.getGanzes().equals(vorhAktuell)) {
                            //transienteDatenRekursivBerechnen(aufg2);
                        }
                    }
                    vorhAktuell.teile = rekursiveListe;
                    // ab hier hat die aktuelle Aufgabe ihre Teile korrekt zugewiesen
                    rekursiveListe.clear();

                    // Summierung der IstStunden und RestStunden der Teile
                    int restStunden = 0;
                    int istStunden = 0;
                    if (vorhAktuell.getTeile() != null) {
                        for (DmAufgabe subVorh : vorhAktuell.getTeile()) {
                            restStunden += subVorh.getRestStunden();
                            istStunden += subVorh.getIstStunden();
                        }
                    }
                    vorhAktuell.setRestStunden(restStunden);
                    vorhAktuell.setIstStunden(istStunden);

                    // Pruefung des zu setzenden Status
                    if (vorhAktuell.getTeile() != null) {
                        DmAufgabeStatus status = vorhAktuell.getTeile().get(1).getStatus();
                        for (DmAufgabe subVorh : vorhAktuell.getTeile()) {
                            if (status == subVorh.getStatus()) {
                                //
                            } else {
                                status = DmAufgabeStatus.inBearbeitung;
                                break;
                            }
                        }
                        vorhAktuell.setStatus(status);
                        aufgAktuell = vorhAktuell;
                    }
                }
                neueListe.add(aufgAktuell);
            }
        }
        List<DmAufgabe> returnListe = neueListe;
        daFac.endTransaction(true);
        return returnListe;
    }

    @Override
    public List<DmVorhaben> alleVorhabenLiefern() {
        daFac.beginTransaction();
        ArrayList<DmVorhaben> neueListe = new ArrayList<>();
        for (DmAufgabe aufgAktuell : ganzeListe) {
            if (aufgAktuell instanceof DmVorhaben) {
                neueListe.add((DmVorhaben) aufgAktuell);
            }
        }
        List<DmVorhaben> resultListe = neueListe;
        daFac.endTransaction(true);
        return resultListe;
    }

    /*
    DmAufgabe transienteDatenRekursivBerechnen(final DmAufgabe aufgabe) {
        if (aufgabe instanceof DmSchritt) {
            return aufgabe;
        } else {
            for (DmAufgabe suche : ganzeListe) {
                if (suche.getGanzes().equals(aufgabe)) {
                    rekursiveListe.add(transienteDatenRekursivBerechnen(suche));
                }
            }
        }
        return null;
    }
     */
    List<DmAufgabe> teileBerechnen(List<DmAufgabe> e) {
        ArrayList<DmAufgabe> resultList = new ArrayList<>();
        for (DmAufgabe aufg : e) {
            if (aufg.getGanzes() == null) {
                resultList.add(aufg);
            }
        }
        return resultList;
    }

    int istStundenBerechnen(final DmAufgabe aufgabe) {
        if (aufgabe instanceof DmSchritt) {
            return aufgabe.getIstStunden();
        }
        int result = 0;
        for (DmAufgabe aufg : aufgabe.getTeile()) {
            result += istStundenBerechnen(aufg);
        }
        return result;
    }

    int restStundenBerechnen(final DmAufgabe aufgabe) {
        if (aufgabe instanceof DmSchritt) {
            return aufgabe.getRestStunden();
        }
        int result = 0;
        for (DmAufgabe aufg : aufgabe.getTeile()) {
            result += restStundenBerechnen(aufg);
        }
        return result;
    }

    DmAufgabeStatus statusBerechnen(final DmAufgabe aufgabe) {
        if (aufgabe instanceof DmSchritt) {
            return aufgabe.getStatus();
        }
        DmAufgabeStatus status = aufgabe.getTeile().get(1).getStatus();
        for (DmAufgabe aufg : aufgabe.getTeile()) {
            if (status != aufg.getStatus()) {
                status = DmAufgabeStatus.inBearbeitung;
            }
        }
        return status;
    }

    /*
    DmAufgabeStatus status = vorhAktuell.getTeile().get(1).getStatus();
                        for (DmAufgabe subVorh : vorhAktuell.getTeile()) {
                            if (status == subVorh.getStatus()) {
                                //
                            } else {
                                status = DmAufgabeStatus.inBearbeitung;
                                break;
                            }
     */
}
