/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package l3_da;

import java.util.List;
import javax.persistence.EntityManager;
import l4_dm.DmAufgabe;

/**
 *
 * @author s844559
 */
class DaAufgabeImpl extends DaGenericImpl<DmAufgabe> implements DaAufgabe{
    
    public DaAufgabeImpl(EntityManager entityManager){
        super(DmAufgabe.class, entityManager);
    }    
}
