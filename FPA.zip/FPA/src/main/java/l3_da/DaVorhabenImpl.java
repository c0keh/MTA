/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package l3_da;

import javax.persistence.EntityManager;
import l4_dm.DmVorhaben;


/**
 *
 * @author s844559
 */
public class DaVorhabenImpl extends DaGenericImpl<DmVorhaben> implements DaVorhaben {
    
    public DaVorhabenImpl(final EntityManager entityManager){
        super(DmVorhaben.class, entityManager);
    }  
}
