package l4_dm;

/**Stellt den Lebenszyklus einer Aufgabe dar.*/
public enum DmAufgabeStatus {
	neu,
	inBearbeitung,
	erledigt
}
