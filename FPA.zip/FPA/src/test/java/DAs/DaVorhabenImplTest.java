/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package DAs;

import l3_da.DaFactoryForJPA;
import l3_da.DaGeneric;
import l3_da.DaVorhaben;
import l4_dm.DmVorhaben;
import org.junit.Assert;
import static org.junit.Assert.fail;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

/**
 *
 * @author Rene
 */
@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class DaVorhabenImplTest {

    private static final DaFactoryForJPA DA_FAC = new DaFactoryForJPA();

    @Test
    public void t01_persistierenOhneRollback() {

        //speichern
        DA_FAC.beginTransaction();
        DaVorhaben daVorhaben1 = DA_FAC.getVorhabenDA();
        DmVorhaben dmVorhaben = new DmVorhaben();
        daVorhaben1.save(dmVorhaben);           //speichern
        DA_FAC.endTransaction(true);            // commit

        //laden und prüfen
        DA_FAC.beginTransaction();
        DaVorhaben daVorhaben2 = DA_FAC.getVorhabenDA();
        Assert.assertEquals(1, daVorhaben2.findAll().size());
        DA_FAC.endTransaction(true);
    }

    @Test
    public void t02_rollbackAusprobieren() {

        //speichern
        DA_FAC.beginTransaction();
        DaVorhaben daVorhaben1 = DA_FAC.getVorhabenDA();
        DmVorhaben dmVorhaben = new DmVorhaben();
        daVorhaben1.save(dmVorhaben);           // speichern
        DA_FAC.endTransaction(false);           // rollback

        //laden und prüfen
        DA_FAC.beginTransaction();
        DaVorhaben daVorhaben2 = DA_FAC.getVorhabenDA();
        Assert.assertEquals(1, daVorhaben2.findAll().size()); // weiterhin Größe 1?
        DA_FAC.endTransaction(true);
    }

    @Test
    public void t03_IdNotFoundExcAusprobieren() throws Exception {
        DA_FAC.beginTransaction();
        final DaVorhaben daVorhaben1 = DA_FAC.getVorhabenDA();
        try {
            daVorhaben1.find(99L);
            fail("DaGeneric.IdNotFoundExc expected");
        } catch (DaGeneric.IdNotFoundExc expected) {
        }
        finally {
        DA_FAC.endTransaction(true);
    }
    }

    @Test
    public void t04_deleteAusprobieren() {

        //löschen
        DA_FAC.beginTransaction();
        DaVorhaben daVorhaben1 = DA_FAC.getVorhabenDA();
        daVorhaben1.delete(daVorhaben1.find(1L));       // erster (und einziger) Eintrag wird gelöscht
        DA_FAC.endTransaction(true);                    // commit

        //laden und prüfen
        DA_FAC.beginTransaction();
        DaVorhaben daVorhaben2 = DA_FAC.getVorhabenDA();
        Assert.assertEquals(0, daVorhaben2.findAll().size());    // leer?
        DA_FAC.endTransaction(true);
    }
}
