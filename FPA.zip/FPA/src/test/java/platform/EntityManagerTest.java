/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package platform;

import java.util.List;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;
import javax.persistence.TypedQuery;
import l4_dm.DmSchritt;
import org.junit.FixMethodOrder;
import org.junit.runners.MethodSorters;
import org.junit.AfterClass;
import org.junit.Assert;
import org.junit.Test;

/**
 *
 * @author Rene
 */
@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class EntityManagerTest {

    private static final String persistenceUnitName = "aufgabenplaner";
    private static final EntityManagerFactory entityManagerFactory = Persistence.createEntityManagerFactory(persistenceUnitName);

    public EntityManagerTest() {
    }

    /**
     * Probiert einige Operationen des JPA-EntityManager aus und protokolliert
     * deren Ergebnisse
     *
     * @param args.
     */
    /**
     * Vereinfachte, ergebnisliefernde Transaktion zur Verwendung in
     * Testtreibern. Diese Transaktion macht immer ein abschließendes commit().
     * Die Nutzaktion muss durch Übergabe eines _Action-Objekts mit einer
     * apply-Methode definiert werden. Dafür sollte ein Lambda-Ausdruck der Form
     * em -> result beziehungsweise em -> {... return result;} verwendet werden.
     * Wenn der Ausdruck nichts zurückgeben soll (wegen Ergebnistyp Void) muss
     * er stattdessen null zurückgeben, da es einen Void-Wert in Java nicht
     * gibt.
     */
    public <RESULT> RESULT _transaction(final _Action<RESULT> action) {
        /**
         * Der {@link EntityManager} mit Transaction Scope für die weiteren Datenzugriffsoperationen.
         */
        final EntityManager em = entityManagerFactory.createEntityManager();
        final EntityTransaction transaction = em.getTransaction();
        transaction.begin();
        final RESULT result = action.apply(em); //Aufruf der Nutzaktion
        transaction.commit();
        em.close();
        return result;
    }

    @FunctionalInterface
    public interface _Action<RESULT> {

        /**
         * Führt die Nutzaktion der _transaction aus. Diese liefert ein Ergebnis
         * vom Typ RESULT.
         */
        RESULT apply(EntityManager em);

    }

    @Test
    public void t01_persistierenOhneRollback() {
        final EntityManager entityManager = entityManagerFactory.createEntityManager();
        final EntityTransaction transaction = entityManager.getTransaction();
        transaction.begin();
        final DmSchritt schritt = new DmSchritt();
        schritt.setTitel("Post abholen");
        Assert.assertNull(schritt.getId());
        entityManager.persist(schritt);
        Assert.assertEquals(Long.valueOf(1), schritt.getId());
        transaction.commit();
        entityManager.close();
    }

    @Test
    public void t02_rollbackAusprobieren() {
        final EntityManager entityManager = entityManagerFactory.createEntityManager();
        final EntityTransaction transaction = entityManager.getTransaction();
        transaction.begin();
        final DmSchritt schritt = new DmSchritt();
        schritt.setTitel("Ein problematischer Schritt");
        entityManager.persist(schritt);
        final Long idOfFailed = schritt.getId();
        Assert.assertEquals(Long.valueOf(2), schritt.getId());
        Assert.assertEquals("Ein problematischer Schritt", schritt.getTitel());
        transaction.rollback();
        Assert.assertEquals(Long.valueOf(2), schritt.getId());
        Assert.assertEquals("Ein problematischer Schritt", schritt.getTitel());
        entityManager.close();

        _transaction(em -> {
            final DmSchritt schritt2 = em.find(DmSchritt.class, idOfFailed);
            Assert.assertNull(schritt2);
            return null;
        });
    }

    @Test
    public void t03_entityMitIdWiederHolenUndAendern() {
        _transaction(em -> {
            final DmSchritt schritt = em.find(DmSchritt.class, 1L);
            Assert.assertEquals(Long.valueOf(1), schritt.getId());
            Assert.assertEquals("Post abholen", schritt.getTitel());
            Assert.assertEquals(0, schritt.getIstStunden());
            schritt.setRestStunden(0);
            schritt.setIstStunden(2);
            return null;
        });
    }

    @Test
    public void t04_detachUndMergePruefen() {
        final DmSchritt schritt;
        {
            schritt = _transaction(em -> {
                final DmSchritt result = em.find(DmSchritt.class, 1L);
                Assert.assertEquals(Long.valueOf(1), result.getId());
                Assert.assertEquals("Post abholen", result.getTitel());
                Assert.assertEquals(2, result.getIstStunden());
                return result;
            });
        }
        schritt.setIstStunden(3);
        _transaction(em -> {
            em.merge(schritt);
            Assert.assertEquals(3, schritt.getIstStunden());
            return null;
        });
    }

    @Test
    public void t05_entityWiederMitIdHolenUndPruefen() {
        final DmSchritt schritt = _transaction(em -> em.find(DmSchritt.class, 1L));
        Assert.assertEquals(3, schritt.getIstStunden());
        Assert.assertEquals(Long.valueOf(1), schritt.getId());
        Assert.assertEquals("Post abholen", schritt.getTitel());
    }

    @Test
    public void t06_schrittNachNeuerTXcloseAendernMergeCloseFind() {
        final List<DmSchritt> results = _transaction(em -> {
            final TypedQuery<DmSchritt> q = em.createQuery("SELECT o FROM " + DmSchritt.class.getName() + " o ORDER BY id DESC", DmSchritt.class);
            return q.getResultList();
        });
        final StringBuilder out = new StringBuilder();
        for (final DmSchritt s : results) {
            out.append("Schritt: id=").append(s.getId()).append(", titel=").append(s.getTitel()).append("\n");
            Assert.assertEquals("Schritt: id=1, titel=Post abholen\n", out.toString());
        }
    }

    @Test
    public void t07_entityWiederMitIdHolen() {
        _transaction(em -> {
            final DmSchritt schritt = em.find(DmSchritt.class, 1L);
            Assert.assertEquals(Long.valueOf(1), schritt.getId());
            Assert.assertEquals("Post abholen", schritt.getTitel());
            em.remove(schritt);
            Assert.assertEquals(Long.valueOf(1), schritt.getId());
            Assert.assertEquals("Post abholen", schritt.getTitel());
            return null;
        });
    }

    @Test
    public void t08_entityNachLoeschenHolen() {
        _transaction(em -> {
            final DmSchritt schritt = em.find(DmSchritt.class, 1L);
            Assert.assertEquals(null, schritt);
            return null;
        });
    }

    @AfterClass
    public static void beenden() {
        entityManagerFactory.close();
    }

}
